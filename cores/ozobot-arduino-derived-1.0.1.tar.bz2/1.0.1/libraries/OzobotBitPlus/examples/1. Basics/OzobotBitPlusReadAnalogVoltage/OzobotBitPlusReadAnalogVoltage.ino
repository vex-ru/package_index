/*
  Ozobot Bit+
  ReadAnalogVoltage

  Reads a light sensor on the Bit+, converts it to voltage, and prints the result to the Serial Monitor.
  Use the Serial Plotter to graph out the readings. (Tools > Serial Plotter).

  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/ReadAnalogVoltage
*/

// this code runs once when you power up the Bit+
void setup() {

  Serial.begin(9600);  // initialize serial communication at 9600 bits per second:
}

//this code will run repeatedly
void loop() {

  int sensorReading = analogRead(PIN_LINE_SENSOR_1);  // read the input on line sensor:
                                                      // valid option for analogRead(); are :
                                                      //PINE_LINE_SENSOR_1, PINE_LINE_SENSOR_2, PINE_LINE_SENSOR_3, PINE_LINE_SENSOR_4


  float voltage = sensorReading * (3.3 / 1023.0);  // convert the analog reading (which goes from 0 - 1023) to a voltage (0 - 3.3V):

  Serial.println(voltage);  // print out the value you read from the sensor:

  delay(1);  // delay (milliseconds) to stablize readouts
}
