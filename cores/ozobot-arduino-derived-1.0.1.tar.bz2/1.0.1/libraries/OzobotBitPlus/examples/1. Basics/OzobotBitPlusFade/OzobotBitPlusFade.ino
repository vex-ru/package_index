/*
  Ozobot Bit+ 
  Fade

  This example shows how to fade the brightness of the built-in top LEDs on the Bit+ using 
  'if' statements and the analogWrite() function.

  The analogWrite() function uses PWM. On the Bit+, the top LEDs and motors all run on PWM!

  modified feb 5 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/Fade
*/

int brightness = 255;  // how bright the LED is. 255 turns the LED off and 0 turns the LED to maximum brightness
int fadeAmount = 5;    // how many points to fade the LED by

// this code runs once when you power up the Bit+
void setup() {
  // declare LED pins to be outputs
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_BLUE, OUTPUT);
}

// this code runs over and over again
void loop() {


  analogWrite(LED_RED, brightness);    // set the brightness of LED(s)
  analogWrite(LED_GREEN, brightness);  // Try commenting out one or two of the LEDs with "//" at the
  analogWrite(LED_BLUE, brightness);   //beginning of the 'analogWrite' commands


  brightness = brightness - fadeAmount;  // change the brightness for next time through the loop:


  if (brightness <= 0 || brightness >= 255) {  // reverse the direction of the fading at the ends of the fade:
    fadeAmount = -fadeAmount;
  }

  delay(50);  // wait for 50 milliseconds to see the LEDs new output
}
