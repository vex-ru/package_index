/*
  Ozobot Bit+
  Blink

  Cycles between the red, green, and blue LED's on the top of the Bit+
  as well as the single white and four green LEDs on the bottom

  modified 8 May 2014
  by Scott Fitzgerald
  modified 2 Sep 2016
  by Arturo Guadalupi
  modified 8 Sep 2016
  by Colby Newman

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/Blink
  */

// this code runs once when you power up the Bit+
void setup() {
  // initialize all LED pins as outputs
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_BLUE, OUTPUT);
  pinMode(LED_SENSORS_GREEN, OUTPUT);
  pinMode(LED_SENSORS_WHITE, OUTPUT);
  // sets all LEDs to off state
  // top LEDs are active LOW (turn off pin to light LED)
  // bottom LEDs are active HIGH (turn on pin to light LED)
  digitalWrite(LED_RED, HIGH);
  digitalWrite(LED_GREEN, HIGH);
  digitalWrite(LED_BLUE, HIGH);
  digitalWrite(LED_SENSORS_GREEN, LOW);
  digitalWrite(LED_SENSORS_WHITE, LOW);


}

//this code will run repeatedly
void loop() {

  digitalWrite(LED_RED, LOW);             // turn the red LED on
  delay(500);                            // wait for a second
  digitalWrite(LED_RED, HIGH);            // turn the red LED off
  delay(500);                            // wait for a second
  digitalWrite(LED_GREEN, LOW);           // turn the green LED on
  delay(500);                            // wait for a second
  digitalWrite(LED_GREEN, HIGH);          // turn the green LED off
  delay(500);                            // wait for a second
  digitalWrite(LED_BLUE, LOW);            // turn the blue LED on
  delay(500);                            // wait for a second
  digitalWrite(LED_BLUE, HIGH);           // turn the blue LED off
  delay(500);                            // wait for a second
  digitalWrite(LED_SENSORS_GREEN, HIGH);  // turn the green LEDs on
  delay(500);                            // wait for a second
  digitalWrite(LED_SENSORS_GREEN, LOW);  // turn the green LEDs off
  delay(500);                            // wait for a second
  digitalWrite(LED_SENSORS_WHITE, HIGH);  // turn the white LED on
  delay(500);                            // wait for a second
  digitalWrite(LED_SENSORS_WHITE, LOW);  // turn the white LED off
  delay(500);                            // wait for a second
}
