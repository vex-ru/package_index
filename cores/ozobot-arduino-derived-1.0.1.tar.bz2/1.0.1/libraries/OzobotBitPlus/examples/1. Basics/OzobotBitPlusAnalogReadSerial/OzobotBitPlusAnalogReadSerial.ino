/*
  Ozobot Bit+
  AnalogReadSerial

  Read the light sensors on the Bit+, prints their state out to the Arduino IDE Serial Monitor.
  Use the Serial Plotter to graph the output (Tools > Serial Plotter)
  
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/AnalogReadSerial
*/

// this code runs once when you power up the Bit+
void setup() {
  // initialize serial communication at 9600 bits per second:
  Serial.begin(9600);
}

//this code will run repeatedly
void loop() {

  int lightSensor = analogRead(PIN_LINE_SENSOR_1);  // read the input of the Bit+ light sensor:
                                                    // valid options are: PIN_LINE_SENSOR_1,
                                                    // PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4

  Serial.println(lightSensor);  // print out the value read light sensor of the Bit+:
  delay(1);                     // delay 1 millisecond for stable analog -> serial output
}
