/*
  Ozobot Bit+
  DigitalReadSerial

  Read the state of the button on your Bit+, print the state out to the Arduino IDE Serial Monitor.
  The built in button is a NO switch meaning that it's 'Normally Open'.
  When we press the button it breaks connection of it's circuit, creating a 0 or LOW logic state.

  modified feb 5 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/DigitalReadSerial
*/

// this code runs once when you power up the Bit+
void setup() {

  Serial.begin(9600);  // begin serial communication at 9600 bits per second:

  pinMode(BUTTON_PIN, INPUT);  // Sets button pin to an input
}

//this code will run repeatedly
void loop() {

  int buttonState = digitalRead(BUTTON_PIN);  // read the button pins state:

  Serial.println(buttonState);  // print out the logic state of the button:

  delay(1);  // delay (milliseconds) between reads for stability
}
