/*
  Ozobot Bit+
  Basic Line Follower

  Make Bit+ follow a black line on white paper

  Uses the Bit+ built-in line sensors to follow a simple path
  using math and custom functions to stay on track

  MIT License

  Copyright (c) 2023 Ozo Edu

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.

  Created 22 Feb 2023
  By Ozobot

*/
const int lineThreshold = 900;  //sets a brightness threshold to determine if the sensor is over a black line

//this code runs once when you power up the Bit+
void setup() {


  digitalWrite(LED_SENSORS_GREEN, HIGH);  //Turns on the green LEDs on the bottom of the Bit+
}

//this code will run repeatedly
void loop() {

  int sensor1 = analogRead(PIN_LINE_SENSOR_1);  //seslects PIN_LINE_SENSOR_1 as sensor1

  int sensor2 = analogRead(PIN_LINE_SENSOR_4);  //seslects PIN_LINE_SENSOR_4 as sensor2

  if ((sensor2 <= lineThreshold) && (sensor1 <= lineThreshold)) {  //if the selected light sensors are over white then it will call the forward function
    forward();
  }

  if ((sensor2 >= lineThreshold) && (sensor1 <= lineThreshold)) {  //if the inner right light sensor is over white and the inner left light sensor is overthen it will call the turnRight
    turnRight();
  }

  if ((sensor2 <= lineThreshold) && (sensor1 >= lineThreshold)) {  //if the inner left light sensor is over white and the inner right light sensor is overthen it will call the turnLeft
    turnLeft();
  }

  if ((sensor2 >= lineThreshold) && (sensor1 >= lineThreshold)) {  //if the selected light sensors are over black then it will call the stop function
    stop();
  }
}

void forward() {  //moves the Bit+ forward

  Ozobot_setMotors(75, 75);     //sets both motors to forward
  analogWrite(LED_GREEN, 200);  //Lights up built-in LED package Green
  analogWrite(LED_RED, 255);
}

void turnRight() {  //turns the Bit+ Right

  Ozobot_setMotors(75, -25);
  analogWrite(LED_GREEN, 220);  //Lights up built-in LED package Yellow
  analogWrite(LED_RED, 200);
}

void turnLeft() {  //turns the Bit+ Left

  Ozobot_setMotors(-25, 75);
  analogWrite(LED_GREEN, 220);  //Lights up built-in LED package Yellow
  analogWrite(LED_RED, 200);
}

void stop() {  //stops the Bit+

  Ozobot_setMotors(0, 0);
  analogWrite(LED_RED, 200);  //Lights up built-in LED package Red
  analogWrite(LED_GREEN, 255);
}
