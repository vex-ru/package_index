/*
  Ozobot Bit+
  Metronome

  Use the Bit+ as a metronome

  Uses the Bit+ motor to and built-in LEDs to indicate which beat 
  the metronome is currently playing in a musical bar

  MIT License

  Copyright (c) 2023 Ozo Edu

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.

  Created 9 Feb 2023
  By Ozobot

*/


const int ledOne = LED_RED;    // selects LED for beat one, valid choices are:
                               // LED_RED, LED_GREEN, LED_BLUE
const int ledTwo = LED_GREEN;  // selects LED for beats two, three, and four
                               // valid choices are: LED_RED, LED_GREEN, LED_BLUE
int currentBeat = 0;           // place holder value for beat count


const int barLength = 4;                                            // sets number of beats before metronome resets
const int tickPitches[barLength] = { 2000, 1000, 1000, 1000 };      // pitches in Hz to be played for each beat
const int beatLed[barLength] = { ledOne, ledTwo, ledTwo, ledTwo };  // maps out LED indicators for each beat
const int bpm = 128;                                                // sets tempo in bpm


// this code runs once when you power up the Bit+
void setup() {
  pinMode(ledOne, OUTPUT);  // sets LED pins to outputs
  pinMode(ledTwo, OUTPUT);
  digitalWrite(ledOne, HIGH);  // set LEDs "off" state
  digitalWrite(ledTwo, HIGH);
}

// the loop routine runs over and over again forever
void loop() {

  int long pauseLength = (54000 / bpm);  // sets pause length so 90% of the beat will be silent
  int long tickLength = (6000 / bpm);    // sets tick length so 10% of the beat will have a tone() output

  tone(MOTOR_LEFT_PWM, tickPitches[currentBeat]);  // plays a pitch on the motor
  analogWrite(beatLed[currentBeat], 200);      // sets LED to a moderate brigtness
  delay(tickLength);                           // how long the tick plays for
  noTone(MOTOR_LEFT_PWM);                      // stops the tone output
  analogWrite(beatLed[currentBeat], 255);      // turns off LED
  delay(pauseLength);                          // how long the tick pauses for
  currentBeat = currentBeat + 1;               // advances to next beat
  if (currentBeat >= barLength) {              // checks to see if beat needs to be reset
    currentBeat = 0;                           // sets beat to first step (0-3)
  }
}
