/*
  Button

  Using code by ToneArt: 
  https://forum.arduino.cc/u/toneart/
  on the Arduino forums made available for anyone to use:
  https://forum.arduino.cc/t/tap-tempo-button-code/642650
*/

#ifndef __Button_h__
#define __Button_h__

#include <Arduino.h>

#define BUTTON_DEBOUNCE_TIME   30   // x ms after button has changed to avoid double clicks


class Button {
  private:
    byte pin;
    byte lastReadState;
    byte currentState;
    unsigned long timeButtonChange;

  public:
    Button();
    void begin(byte pin); 
    bool hasBeenPressed(); // has to be call regularly to check the button status
};

#endif