/*
  Ozobot Bit+
  Tap Tempo Metronome

  Sketch to illustrate how using millis() instead of delay() allows to update
  variables without waiting for the delay() function to finish.

  Use the Bit+ as a metronome with 'tap tempo' functionality, without waiting
  for a cycle to finish or to change variables in the software.

  Just upload the code to your Bit+ and press the button. The software averages 
  up to six sequential button pushes to calculate how many beats-per-minute
  to set the metronome at.

  MIT License

  Copyright (c) 2023 Ozo Edu

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.

  Created 9 Feb 2023
  By Ozobot

  Using code by ToneArt: 
  https://forum.arduino.cc/u/toneart/
  on the Arduino forums made available for anyone to use:
  https://forum.arduino.cc/t/tap-tempo-button-code/642650
*/


#include "TapTempoButton.h"

#define TAP_TEMPO_BUTTON_PIN BUTTON_PIN  // assigns TAP_TEMPO input to built-in button

TapTempoButton tapTempo;  // sets variable for TapTempoButton class


unsigned long previousMillis = 0;                                   // sets starting value
boolean tickActive = false;                                         // sets true/false state
int ledOne = LED_RED;                                               // selects LED for beat one, valid choices are:
                                                                    // LED_RED, LED_GREEN, LED_BLUE
int ledTwo = LED_GREEN;                                             // selects LED for beat one, valid choices are:
                                                                    // LED_RED, LED_GREEN, LED_BLUE
const int barLength = 4;                                            // sets number of beats before metronome resets
const int tickPitches[barLength] = { 2000, 1000, 1000, 1000 };      // pitches in Hz to be played for each beat
const int beatLed[barLength] = { ledOne, ledTwo, ledTwo, ledTwo };  // maps out LED indicators for each beat
int currentBeat = 0;                                                // place holder value for beat count
unsigned long currentMillis;                                        // declares currentMillis as a variable

// this code runs once when you power up the Bit+
void setup() {
  tapTempo.begin(BUTTON_PIN);  // starts tapTempo class and declares input
  Serial.begin(9600);          // begins serial communcation at 9600 bytes per second
  pinMode(ledOne, OUTPUT);     // sets LED pins to outputs
  pinMode(ledTwo, OUTPUT);
  digitalWrite(ledOne, HIGH);  // set LEDs "off" state
  digitalWrite(ledTwo, HIGH);
}

// the loop routine runs over and over again forever
void loop() {
  currentMillis = millis();          // updates currentMillis value for math in loop()
  if (tapTempo.hasTempoChanged()) {  // check tapTempo class for change in tempo value
    Serial.print("New tempo: ");     // prints tempo out to serial monitor
    Serial.println(tapTempo.getTempo());
  }
  int long bpm = tapTempo.getTempo();    // sets bpm to last tapTempo output
  int long pauseLength = (54000 / bpm);  // sets pause length so 90% of the beat will be silent
  int long tickLength = (6000 / bpm);    // sets tick length so 10% of the beat will have a tone() output

  if (tickActive) {                                      // checks if tick boolen is true
    if (currentMillis - previousMillis >= tickLength) {  // if tick is playing checks how long it has played for
                                                         // and if an update needs to be made
      previousMillis = currentMillis;                    // updates previousMillis value
      analogWrite(beatLed[currentBeat], 255);            // shuts off LED
      noTone(MOTOR_LEFT_PWM);                            // stops tone playback on motor
      tickActive = false;                                // sets tick boolean to false
      currentBeat = currentBeat + 1;                     // updates Current beat for tone and LED output
      if (currentBeat >= barLength) {                    // checks to see if beat needs to be reset
        currentBeat = 0;                                 // sets beat to first step (0-3)
      }
    }
  } else {                                                // instructs what to do if the tick is not playing
    if (currentMillis - previousMillis >= pauseLength) {  // checks to see how long the tick has been silent
                                                          // and if it need to update anything
      previousMillis = currentMillis;                     // updated previousMillis value
      analogWrite(beatLed[currentBeat], 200);             // sets LED to a moderate brightness
      tone(MOTOR_LEFT_PWM, tickPitches[currentBeat]);     // plays pitch to motor based off of currentBeat
      tickActive = true;                                  // sets tick boolean to true
    }
  }
}
