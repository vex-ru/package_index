/*
  Tap Tempo Button

  Using code by ToneArt: 
  https://forum.arduino.cc/u/toneart/
  on the Arduino forums made available for anyone to use:
  https://forum.arduino.cc/t/tap-tempo-button-code/642650
*/

#include "TapTempoButton.h"


TapTempoButton::TapTempoButton() :
    tempo(0),
    lastTapTime(0),
    tapTimes{0} {
     
}

word TapTempoButton::getTempo() {
  return this->tempo;
}

bool TapTempoButton::hasTempoChanged() { // to call once per loop()
  if (!this->hasBeenPressed())
    return false;

  unsigned long now = millis();
  if (now - this->tapTimes[this->lastTapTime] > TAPTEMPO_TIMEBETWEEN) { // start over
    this->tapTimes[0] = now;
    this->lastTapTime = 0;
    return false;
  }
 
  // has been tapped at least once
  if (this->lastTapTime < TAPTEMPO_AMOUNT_OF_TAPS-1) {
    this->lastTapTime++;
    this->tapTimes[this->lastTapTime] = now;
  }
  else { // we have TAPTEMPO_AMOUNT_OF_TAPS taps, we need to shift all the values
    for (byte i = 1 ; i <= this->lastTapTime ; i++)
      this->tapTimes[i-1] = this->tapTimes[i];
    this->tapTimes[this->lastTapTime] = now;
  }

  word timeDifferences = 0;
  for (byte j = 1 ; j <= this->lastTapTime ; j++)
    timeDifferences += this->tapTimes[j] - this->tapTimes[j-1];

  this->tempo = (60000*this->lastTapTime) / timeDifferences; // timeDiff / lastTapTime = average of the time diff between taps
  if (this->tempo > TAPTEMPO_MAXTEMPO)
    this->tempo = TAPTEMPO_MAXTEMPO;
  return true;
}