/*
  Button

  Using code by ToneArt: 
  https://forum.arduino.cc/u/toneart/
  on the Arduino forums made available for anyone to use:
  https://forum.arduino.cc/t/tap-tempo-button-code/642650
*/

#include "Button.h"

Button::Button()
  : lastReadState(LOW),
    currentState(LOW),
    pin(NOT_A_PIN),
    timeButtonChange(0) {
}

void Button::begin(byte pin) {
  pinMode(pin, INPUT_PULLUP);
  byte st = digitalRead(pin);
  this->lastReadState = st;
  this->currentState = st;
  this->pin = pin;
}

bool Button::hasBeenPressed() {
  byte newState = digitalRead(this->pin);
  bool returnVal = false;
  unsigned long currentTime = millis();
  if (newState != this->lastReadState) {  // has changed - because of noise or because the button is being pressed
    this->timeButtonChange = currentTime;
    this->lastReadState = newState;
  } else if ((currentTime - this->timeButtonChange) > long(BUTTON_DEBOUNCE_TIME)) {  // state has been stable for x ms
    if (this->currentState == HIGH && newState == LOW)                               // HIGH to LOW = pressed (with pullup resistor)
      returnVal = true;
    this->currentState = newState;
  }
  return returnVal;
}