/*
  Ozobot Bit+ 
  Analog input, analog output, serial output

  Reads a Bit+ light sensor, maps the result to a range from 0 to 255 and uses
  the result to set the pulse width modulation (PWM) output of an LED.
  Also prints the results to the Serial Monitor.
  
  created 29 Dec. 2008
  modified 9 Apr 2012
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/AnalogInOutSerial
*/

// These constants won't change. They're used to give names to the pins used:
const int analogInPin = PIN_LINE_SENSOR_1;  // Which light sensor the Bit+ is reading from
                                            // valid options are; PIN_LINE_SENSOR_1, PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4
const int analogOutPin = LED_BLUE;  // Analog output pin that the LED is attached to
                                    // valid options are LED_RED, LED_GREEN, LED_BLUE

int sensorValue = 0;  // value read from the light sensor
int ledValue = 0;  // PWM output to selected LED

// this code runs once when you power up the Bit+
void setup() {
  // initialize serial communications at 9600 bps:
  Serial.begin(9600);
}

//this code will run repeatedly
void loop() {
  // read the light sensor value:
  sensorValue = analogRead(analogInPin);
  // map it to the range of the analog out:
  ledValue = map(sensorValue, 0, 1023, 0, 255);
  // change the analog out value of the LED:
  analogWrite(analogOutPin, ledValue);

  // print the results to the Serial Monitor:
  Serial.print("sensor = ");
  Serial.print(sensorValue);
  Serial.print("\t output = ");
  Serial.println(ledValue);

  // wait 5 milliseconds in increase stability of analog -> serial
  delay(5);
}
