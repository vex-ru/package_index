/*
  Ozobot Bit+
  Smoothing

  Reads repeatedly from an analog input, calculating a running average and
  printing it to the Serial Monitor and outputs . Keeps ten readings in an array and continually
  averages them.

  created 22 Apr 2007
  by David A. Mellis  <dam@mellis.org>
  modified 9 Apr 2012
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/Smoothing
*/

// Define the number of samples to keep track of. The higher the number, the
// more the readings will be smoothed, but the slower the output will respond to
// the input. Using a constant rather than a normal variable lets us use this
// value to determine the size of the readings array.
const int numReadings = 10;
const int ledPin = LED_BLUE;  // LED selected to output PWM
                              // valid options are: LED_RED, LED_GREEN, LED_BLUE

int readings[numReadings];  // the readings from the analog input
int readIndex = 0;          // the index of the current reading
int total = 0;              // the running total
int average = 0;            // the average

int inputPin = PIN_LINE_SENSOR_1;  // selects which light sensor you are calculating averages from
                                   // valid options are: PIN_LINE_SENSORS_1, PIN_LINE_SENSORS_2, PIN_LINE_SENSORS_3, PIN_LINE_SENSORS_4

// this code runs once when you power up the Bit+
void setup() {

  Serial.begin(9600);  // initialize serial communication with computer:

  for (int thisReading = 0; thisReading < numReadings; thisReading++) {  // initialize all the readings to 0:
    readings[thisReading] = 0;
  }
}

//this code will run repeatedly
void loop() {

  total = total - readings[readIndex];  // subtract the last reading:

  readings[readIndex] = analogRead(inputPin);  // read from the sensor:

  total = total + readings[readIndex];  // add the reading to the total:

  readIndex = readIndex + 1;  // advance to the next position in the array:


  if (readIndex >= numReadings) {  // if we're at the end of the array...

    readIndex = 0;  // ...wrap around to the beginning:
  }


  average = total / numReadings;  // calculate the average:

  Serial.println(average);  // send it to the computer as ASCII digits

  analogWrite(ledPin, (average) / 4);  // divide average by 4 to convert to PWM range

  delay(100);  // delay in between reads for stability
}