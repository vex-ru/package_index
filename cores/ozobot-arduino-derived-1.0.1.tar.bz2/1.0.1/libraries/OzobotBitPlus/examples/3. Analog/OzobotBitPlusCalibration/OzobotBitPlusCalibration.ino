/*
  Ozobot Bit+
  Calibration

  Demonstrates one technique for calibrating sensor input. The sensor readings
  during the first five seconds of the sketch execution define the minimum and
  maximum of expected values attached to the selected light sensor.

  The sensor minimum and maximum initial values may seem backwards. Initially,
  you set the minimum high and listen for anything lower, saving it as the new
  minimum. Likewise, you set the maximum low and listen for anything higher as
  the new maximum.

  created 29 Oct 2008
  by David A Mellis
  modified 30 Aug 2011
  by Tom Igoe
  modified 07 Apr 2017
  by Zachary J. Fields
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/Calibration
*/

// These constants won't change:
const int sensorPin = PIN_LINE_SENSOR_1;  // light sensor selected for calibration and input value for PWM output
                                          // valid options are: PIN_LINE_SENSOR_1, PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4
const int ledPin = LED_BLUE;              // LED selected to output PWM
                                          // valid options are: LED_RED, LED_GREEN, LED_BLUE
const int calibrationLed = LED_RED;       //set the LED to indicate calibration is underway
                                          // valid options are: LED_RED, LED_GREEN, LED_BLUE, LED_SENSORS_GREEN, LED_SENSORS_WHITE
// variables:
int sensorValue = 0;   // the sensor value
int sensorMin = 1023;  // minimum sensor value
int sensorMax = 0;     // maximum sensor value

// this code runs once when you power up the Bit+
void setup() {
  // turn on LED to signal the start of the calibration period:
  pinMode(calibrationLed, OUTPUT);
  digitalWrite(calibrationLed, LOW);


  while (millis() < 5000) {  // calibrate during the first five seconds
    sensorValue = analogRead(sensorPin);
    if (sensorValue > sensorMax) {  // record the maximum sensor value
      sensorMax = sensorValue;
    }
    if (sensorValue < sensorMin) {  // record the minimum sensor value
      sensorMin = sensorValue;
    }
  }
  digitalWrite(calibrationLed, HIGH);  // signal the end of the calibration period
}

//this code will run repeatedly
void loop() {
  sensorValue = analogRead(sensorPin);                           // read the selected light sensor of Bit+:
  sensorValue = constrain(sensorValue, sensorMin, sensorMax);    // if the light sensor value is brighter or darker than calibration, force it within calibration range
  sensorValue = map(sensorValue, sensorMin, sensorMax, 0, 255);  // apply the calibration to the sensor reading
  analogWrite(ledPin, sensorValue);                              // write mapped PWM output from selected light sensor to selected LED
}