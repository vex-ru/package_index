/*
  Ozobot Bit+
  Analog Input

  Demonstrates analog input by reading an analog light sensor built-in to the Bit+
  turning on and off an LED that is also built-in to the Bit+
  The amount of time the LED will be on and off depends on the value obtained
  by analogRead().

  created by David Cuartielles
  modified 30 Aug 2011
  By Tom Igoe
  modified 5 Feb 2023
  By Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/AnalogInput
*/

int sensorPin = PIN_LINE_SENSOR_1;  // select a sensor on the bottom of the Bit+
                                    // alid input options are PIN_LINE_SENSOR_1, PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4
int ledPin = LED_BLUE;              // select LED you wish to use
                                    // valid output options are LED_RED, LED_GREEN, LED_BLUE, LED SENSORS_GREEN, LED_SENSORS_WHITE
int sensorValue = 0;                // variable to store the value coming from the sensor

// this code runs once when you power up the Bit+
void setup() {
  // declare the ledPin as an OUTPUT:
  pinMode(ledPin, OUTPUT);
}

//this code will run repeatedly
void loop() {
  // read the value from the sensor:
  sensorValue = analogRead(sensorPin);
  // set LED pin to HIGH
  digitalWrite(ledPin, HIGH);
  // stop the program for <sensorValue> milliseconds:
  delay(sensorValue);
  // set LED pin to LOW:
  digitalWrite(ledPin, LOW);
  // stop the program for for <sensorValue> milliseconds:
  delay(sensorValue);
}
