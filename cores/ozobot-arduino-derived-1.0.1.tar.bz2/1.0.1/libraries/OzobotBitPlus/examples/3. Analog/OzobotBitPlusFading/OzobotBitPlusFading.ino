/*
  Ozobot Bit+
  Fading

  This example shows how to fade the brightness of the built-in top LEDs on the Bit+ using 
  'for' statements and the analogWrite() function.

  created 1 Nov 2008
  by David A. Mellis
  modified 30 Aug 2011
  by Tom Igoe
  modified 5 Feb 2023

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/Fading
*/

int ledPin = LED_BLUE;  // LED selected to output PWM
                        // valid options are: LED_RED, LED_GREEN, LED_BLUE

// this code runs once when you power up the Bit+
void setup() {
  // nothing happens in setup
}

//this code will run repeatedly
void loop() {

  for (int fadeValue = 0; fadeValue <= 255; fadeValue += 5) {  // fade in from min to max in increments of 5 points:

    analogWrite(ledPin, fadeValue);  // sets the value (range from 0 to 255):

    delay(50);  // wait for 50 milliseconds to see the dimming effect
  }


  for (int fadeValue = 255; fadeValue >= 0; fadeValue -= 5) {  // fade out from max to min in increments of 5 points:

    analogWrite(ledPin, fadeValue);  // sets the value (range from 0 to 255):

    delay(50);  // wait for 50 milliseconds to see the dimming effect
  }
}
