/*
  Ozobot Bit+
  Arrays

  Demonstrates the use of an array to hold LEDs in order to iterate over
  in a sequence. Lights the built-in LEDs in sequence, then in reverse.

  Unlike the For Loop tutorial, where the pins have to be sequential, here the
  pins can be in any random order.


  created 2006
  by David A. Mellis
  modified 30 Aug 2011
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/Arrays
*/

int timer = 250;   // The higher the number, the slower the timing.
int ledPins[] = {  // LEDs in the Bit+
  LED_RED, LED_GREEN, LED_BLUE, LED_SENSORS_GREEN, LED_SENSORS_WHITE
};
int ledStates[] = {  // the off states of the LEDs
  HIGH, HIGH, HIGH, LOW, LOW
};
int pinCount = 5;  // the number of pins (i.e. the length of the array)

// this code runs once when you power up the Bit+
void setup() {
  // the array elements are numbered from 0 to 4 (pinCount - 1).
  // use a for loop to initialize each pin as an output:
  for (int thisPin = 0; thisPin < pinCount; thisPin++) {
    pinMode(ledPins[thisPin], OUTPUT);
    //set logic states for corresponding LED
    digitalWrite(ledPins[thisPin], ledStates[thisPin]);
  }
}

//this code will run repeatedly
void loop() {
  // loop from the lowest LED output to the highest:
  for (int thisPin = 0; thisPin < pinCount; thisPin++) {
    // turn the LED output on:
    digitalWrite(ledPins[thisPin], !ledStates[thisPin]);
    delay(timer);
    // turn the LED output off:
    digitalWrite(ledPins[thisPin], ledStates[thisPin]);
    delay(timer);
  }

  // loop from the highest LED output to the lowest:
  for (int thisPin = pinCount - 1; thisPin >= pinCount; thisPin--) {
    // turn the LED output on:
    digitalWrite(ledPins[thisPin], !ledStates[thisPin]);
    delay(timer);
    // turn the pin output off:
    digitalWrite(ledPins[thisPin], ledStates[thisPin]);
    delay(timer);
  }
}
