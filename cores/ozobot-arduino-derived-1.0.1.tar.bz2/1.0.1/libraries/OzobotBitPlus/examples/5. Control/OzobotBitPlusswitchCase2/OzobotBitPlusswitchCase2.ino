/*
  Ozobot Bit+
  Switch statement with serial input

  Demonstrates the use of a switch statement. The switch statement allows you
  to choose from among a set of discrete values of a variable. It's like a
  series of if statements.

  To see this sketch in action, open the Serial monitor and send any character.
  The characters a, b, c, d, and e, will turn on LEDs. Any other character will
  turn the LEDs off.

  created 1 Jul 2009
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/SwitchCase2
*/

int ledPins[] = {
  LED_RED, LED_GREEN, LED_BLUE, LED_SENSORS_GREEN, LED_SENSORS_WHITE
};  // LEDs in the Bit+
int ledOnStates[] = {
  LOW, LOW, LOW, HIGH, HIGH
};  // the off states of the LEDs
int pinCount = 5;    // the number of pins (i.e. the length of the array)

// this code runs once when you power up the Bit+
void setup() {
  // initialize serial communication:
  Serial.begin(9600);
  // initialize the LED pins:
  for (int thisPin = 0; thisPin < pinCount; thisPin++) {
    pinMode(ledPins[thisPin], OUTPUT);
    // turn the particular LED off
    digitalWrite(ledPins[thisPin], !ledOnStates[thisPin]);
  }
}

//this code will run repeatedly
void loop() {
  // read the sensor:
  if (Serial.available() > 0) {
    int inByte = Serial.read();
    // do something different depending on the character received.
    // The switch statement expects single number values for each case; in this
    // example, though, you're using single quotes to tell the controller to get
    // the ASCII value for the character. For example 'a' = 97, 'b' = 98,
    // and so forth:
    int pinId;
    switch (inByte) {
      case 'a':
        pinId = 0;
        break;
      case 'b':
        pinId = 1;
        break;
      case 'c':
        pinId = 2;
        break;
      case 'd':
        pinId = 3;
        break;
      case 'e':
        pinId = 4;
        break;
      default:
        // turn all the LEDs off:
        for (int thisPin = 0; thisPin < pinCount; thisPin++) {
          digitalWrite(ledPins[thisPin], !ledOnStates[thisPin]);
        }
    }
    digitalWrite(ledPins[pinId], ledOnStates[pinId]);
  }
}