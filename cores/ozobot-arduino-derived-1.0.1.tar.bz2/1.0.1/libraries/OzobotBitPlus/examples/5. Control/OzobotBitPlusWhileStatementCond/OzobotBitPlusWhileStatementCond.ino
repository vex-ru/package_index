/*
  Ozobot Bit+ 
  Conditionals - while statement

  This example demonstrates the use of  while() statements.

  While the built-in button is pressed, the Bit+ will calibrate the
  selected on-board light sensor/

  This is a alternative method to calibrate sensors.

  created 17 Jan 2009
  modified 30 Aug 2011
  by Tom Igoe
  modified 20 Jan 2017
  by Arturo Guadalupi
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/WhileStatementConditional
*/


// These constants won't change:
const int sensorPin = PIN_LINE_SENSOR_1;        // light sensor to calibrate
                                                // valid choices are: PIN_LINE_SENSOR_1, PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4
const int ledPin = LED_BLUE;                    // pin that the LED is attached to
                                                // valid choices are: LED_RED, LED_GREEN, LED_BLUE
const int indicatorLedPin = LED_SENSORS_GREEN;  // selected LED to indicate calibration is taking place
                                                // valid choices are: LED_RED, LED_GREEN, LED_BLUE, LED_SENSORS_GREEN, LED_SENSORS_WHITE
const int buttonPin = BUTTON_PIN;               // built-in button


// These variables will change:
int sensorMin = 1023;  // minimum sensor value
int sensorMax = 0;     // maximum sensor value
int sensorValue = 0;   // the sensor value

// this code runs once when you power up the Bit+
void setup() {

  pinMode(indicatorLedPin, OUTPUT);  // set the LED pins as outputs and the switch pin as input:
  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT);
}

//this code will run repeatedly
void loop() {

  while (digitalRead(buttonPin) == LOW) {  // while the button is pressed, take calibration readings:
    calibrate();
  }
  digitalWrite(indicatorLedPin, LOW);  // signal the end of the calibration period

  sensorValue = analogRead(sensorPin);  // read the selected light sensor:

  sensorValue = map(sensorValue, sensorMin, sensorMax, 0, 255);  // apply the calibration to the selected light sensor reading

  sensorValue = constrain(sensorValue, 0, 255);  // in case the sensor value is outside the range seen during calibration

  analogWrite(ledPin, sensorValue);  // fade the LED using the calibrated value:
}

void calibrate() {

  digitalWrite(indicatorLedPin, HIGH);  // turn on the indicator LED to indicate that calibration is happening:

  sensorValue = analogRead(sensorPin);  // read the sensor:

  if (sensorValue > sensorMax) {  // record the maximum sensor value during calibration
    sensorMax = sensorValue;
  }

  if (sensorValue < sensorMin) {  // record the minimum sensor value during calibration
    sensorMin = sensorValue;
  }
}