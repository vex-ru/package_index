/*
  Ozobot Bit+
  Switch statement

  Demonstrates the use of a switch statement. The switch statement allows you
  to choose from among a set of discrete values of a variable. It's like a
  series of if statements.

  To see this sketch in action, hold the Bit+ in a well-lit room,
  open the Serial Monitor, and point the bottom of the Bit+ plus towards the light
  and then away from the light, see how the output changes in the Serial Monitor.

  created 1 Jul 2009
  modified 9 Apr 2012
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/SwitchCase
*/

// these constants won't change. They are the lowest and highest readings you
// get from your sensor:
const int sensorMin = 400;   // sensor minimum, discovered through experiment
const int sensorMax = 1023;  // sensor maximum, discovered through experiment
                             // you may need to adjust these values to your testing environment
                             // higher values = less light hitting sensor, lower values = more light hitting sensor

// this code runs once when you power up the Bit+
void setup() {

  Serial.begin(9600);  // initialize serial communication:
}

//this code will run repeatedly
void loop() {

  int sensorReading = analogRead(PIN_LINE_SENSOR_1);           // read the sensor
                                                               // valid options are: PIN_LINE_SENSOR_1, PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4
  int range = map(sensorReading, sensorMin, sensorMax, 3, 0);  // map the sensor range to a range of four options:


  switch (range) {  // do something different depending on the range value:
    case 0:
      Serial.println("dark");  // there's almost no light hitting the sensor
      break;
    case 1:
      Serial.println("dim");  // there's a little light hitting the sensor
      break;
    case 2:
      Serial.println("medium");  // there's some light hitting the sensor
      break;
    case 3:
      Serial.println("bright");  // there's a lot of light hitting the sensor
      break;
  }
  delay(1);  // delay in between reads for stability
}
