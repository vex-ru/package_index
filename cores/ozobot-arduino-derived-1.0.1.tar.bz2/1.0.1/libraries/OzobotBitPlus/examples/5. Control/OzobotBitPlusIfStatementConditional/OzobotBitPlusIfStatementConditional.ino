/*
  OzoBot Bit+
  Conditionals - If statement

  This example demonstrates the use of if() statements.
  It reads the state of a light sensor on Bit+ and turns on an LED
  only if the light sensor goes below a certain threshold level. It prints the
  analog value regardless of the level.

  created 17 Jan 2009
  modified 9 Apr 2012
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/ifStatementConditional
*/

// These constants won't change:
const int analogPin = PIN_LINE_SENSOR_1;  // pin that the sensor is attached to
                                          // valid options are PIN_LINE_SENSOR_1, PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4
const int ledPin = LED_BLUE;              // pin that the LED is attached to
                                          // valid options are :LED_RED, LED_GREEN, LED_BLUE, LED_SENSORS_GREEN, LED_SENSORS_WHITE
const int threshold = 800;                // an arbitrary threshold level that's in the range of the analog input

// this code runs once when you power up the Bit+
void setup() {

  pinMode(ledPin, OUTPUT);  // initialize the LED pin as an output:
  Serial.begin(9600);       // initialize serial communications:
}

//this code will run repeatedly
void loop() {

  int analogValue = analogRead(analogPin);  // read the value of the selected light sensor:


  if (analogValue > threshold) {  // if the analog value is low enough enough, sets LED pin to HIGH:
    digitalWrite(ledPin, HIGH);
  } else {
    digitalWrite(ledPin, LOW);  // otherwise it sets LED pin to LOW
  }


  Serial.println(analogValue);  // print the analog value:
  delay(1);                     // delay in between reads for stability
}
