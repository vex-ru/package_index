/*
  Ozobot Bit+
  Virtual Colour Mixer
  This example reads three analog sensors (potentiometers are easiest) and sends
  their values serially and converts it to LED outputs. 

  created 2 Dec 2006
  by David A. Mellis
  modified 30 Aug 2011
  by Tom Igoe and Scott Fitzgerald
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/VirtualColorMixer
*/

const int redPin = PIN_LINE_SENSOR_1;    // sensor to control red color
const int redLed = LED_RED;              // red LED output
const int greenPin = PIN_LINE_SENSOR_2;  // sensor to control green color
const int greenLed = LED_GREEN;          // green LED output
const int bluePin = PIN_LINE_SENSOR_3;   // sensor to control blue color
const int blueLed = LED_BLUE;            // blue LED output

// this code runs once when you power up the Bit+
void setup() {
  Serial.begin(9600);
}

//this code will run repeatedly
void loop() {
  int redSensor = analogRead(redPin);      // analog reading of selected sensor for Red
  int greenSensor = analogRead(greenPin);  // analog reading of selected sensor for Green
  int blueSensor = analogRead(bluePin);    // analog reading of selected sensor for Blue

  Serial.print(analogRead(redSensor));     // prints out virtual red sensor Reading
  Serial.print(",");                       // prints out comma for readability
  Serial.print(analogRead(greenSensor));   // prints out virtual green sensor Reading
  Serial.print(",");                       // prints out comma for readability
  Serial.println(analogRead(blueSensor));  // prints out virtual blue sensor Reading

  analogWrite(redLed, map(redSensor, 0, 1024, 0, 255));      // outputs "red" value from sensor to red LED
  analogWrite(greenLed, map(greenSensor, 0, 1024, 0, 255));  // outputs "green" value from sensor to green LED
  analogWrite(blueLed, map(redSensor, 0, 1024, 0, 255));     // outputs "blue" value from sensor to blue LED
  delay(50);
}
