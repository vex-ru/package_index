/*
  Ozobot Bit+
  Physical Pixel

  Talk to your Bit+! In this example use the serial interface to contol an LED
  Open the serial monitor and Type 'H' to switch the ledPin to HIGH 
  or type 'L'to switch the ledPin to LOW

  
  created 2006
  by David A. Mellis
  modified 30 Aug 2011
  by Tom Igoe and Scott Fitzgerald
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/PhysicalPixel
*/



int incomingByte;  // a variable to read incoming serial data into

// this code runs once when you power up the Bit+
void setup() {

  Serial.begin(9600);  // initialize serial communication:

  pinMode(LED_RED, OUTPUT);      // initialize the LED pin as an output:
  pinMode(LED_GREEN, OUTPUT);    // initialize the LED pin as an output:
  pinMode(LED_BLUE, OUTPUT);     // initialize the LED pin as an output:
  digitalWrite(LED_BLUE, HIGH);  // sets LED to off as default state
}

//this code will run repeatedly
void loop() {

  if (Serial.available() > 0) {  // see if there's incoming serial data:

    incomingByte = Serial.read();  // read the oldest byte in the serial buffer:

    if (incomingByte == '0') {  // if it's a 0 (zero, ASCII 48) shuts off LEDs
      digitalWrite(LED_RED, HIGH);
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, HIGH);
    }
        if (incomingByte == 'A') {  // if it's an A (ASCII 65), makes aqua colour
      digitalWrite(LED_RED, HIGH);
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, LOW);
    }
    if (incomingByte == 'B') {  // if it's an B (ASCII 66), makes blue colour
      digitalWrite(LED_RED, HIGH);
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, LOW);
    }
    if (incomingByte == 'G') {  // if it's an G (ASCII 71), makes green colour
      digitalWrite(LED_RED, HIGH);
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, HIGH);
    }
    if (incomingByte == 'P') {  // if it's an P (ASCII 80), makes purple colour
      digitalWrite(LED_RED, LOW);
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, LOW);
    }
    if (incomingByte == 'R') {  // if it's an R (ASCII 82), makes red colour
      digitalWrite(LED_RED, LOW);
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, HIGH);
    }
    if (incomingByte == 'W') {  // if it's an W (ASCII 87), makes white light
      digitalWrite(LED_RED, LOW);
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, LOW);
    }
    if (incomingByte == 'Y') {  // if it's an Y (ASCII 89), makes yellow colour
      digitalWrite(LED_RED, LOW);
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, HIGH);
    }
  }
}