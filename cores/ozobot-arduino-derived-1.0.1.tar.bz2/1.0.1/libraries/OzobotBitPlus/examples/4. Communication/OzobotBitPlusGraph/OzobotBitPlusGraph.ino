/*
  Ozobot Bit+
  Graph

  A simple example of communication from the Arduino board to the computer: The
  value of a light sensor on the Bit+ is sent out the serial port. We call this "serial"
  communication because the connection appears to both the Arduino and the
  computer as a serial port, even though it may actually use a USB cable. Bytes
  are sent one after another (serially) from the Arduino to the computer.

  created 2006
  by David A. Mellis
  modified 9 Apr 2012
  by Tom Igoe and Scott Fitzgerald
  modified 5 Feb 2023
  by Ozobot
  
  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/Graph
*/

const int sensorPin = PIN_LINE_SENSOR_1;  // which light sensor on the Bit+ you wish to use
                                          // PIN_LINE_SENSOR_1, PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4

// this code runs once when you power up the Bit+
void setup() {

  Serial.begin(9600);  // initialize the serial communication:
}

//this code will run repeatedly
void loop() {

  int sensorReading = analogRead(sensorPin);  // makes a variable from the light sensor reading

  Serial.println(sensorReading);  // send the value of sensorPin:

  delay(2);  // wait a two milliseconds for the analog-to-digital converter to stabilize after the last
  // reading:
}