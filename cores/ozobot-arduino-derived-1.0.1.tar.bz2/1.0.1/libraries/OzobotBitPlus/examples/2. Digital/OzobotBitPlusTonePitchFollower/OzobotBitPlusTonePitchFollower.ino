/*
  Ozobot Bit+ Pitch follower

  Plays two pitches on the Ozobot Bit+ that "follow" the Bit+ light sensors input values

  created 21 Jan 2010
  modified 31 May 2012
  by Tom Igoe, with suggestion from Michael Flynn
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/tonePitchFollower
*/

// this code runs once when you power up the Bit+
void setup() {

  Serial.begin(9600);  // begin serial communications
}

//this code will run repeatedly
void loop() {


  int sensorReadingL = analogRead(PIN_LINE_SENSOR_1);  // read the light sensors:
  int sensorReadingR = analogRead(PIN_LINE_SENSOR_4);  // valid options are PIN_LINE_SENSOR_1, PIN_LINE_SENSOR_2, PIN_LINE_SENSOR_3, PIN_LINE_SENSOR_4

  Serial.print(sensorReadingL);  // print the sensor reading so you know its usable range in your environment
  Serial.print(", ");
  Serial.println(sensorReadingR);




  int thisPitchL = map(sensorReadingL, 127, 1023, 60, 1200);  // map the light sensor input range (in this case, 127 - 1023 from the light sensors)
  int thisPitchR = map(sensorReadingR, 127, 1023, 60, 1200);  // to the motor output pitch range (60 - 1200Hz)
                                                              // change the minimum and maximum input numbers below depending on the range
                                                              // your sensor's readings

  tone(MOTOR_LEFT_PWM, thisPitchL, 10);  // play the pitch on the Bit+ motors
  tone(MOTOR_RIGHT_PWM, thisPitchR, 10);
  delay(5);  // delay in between reads for stability
}
