/*
  Ozobot Bit+
  State change detection (edge detection)

  Often, you don't need to know the state of a digital input all the time, but
  you just need to know when the input changes from one state to another.
  For example, you want to know when a button goes from OFF to ON. This is called
  state change detection, or edge detection.

  This example shows how to detect when a button or button changes from off to on
  and on to off.

  created  27 Sep 2005
  modified 30 Aug 2011
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/StateChangeDetection
*/

// this constant won't change:
const int buttonPin = BUTTON_PIN;  // the pin that the pushbutton is attached to
const int ledPin = LED_BLUE;       // the pin that the LED is attached to

// Variables will change:
int buttonPushCounter = 0;  // counter for the number of button presses
int buttonState = 0;        // current state of the button
int lastButtonState = 0;    // previous state of the button

// this code runs once when you power up the Bit+
void setup() {

  pinMode(buttonPin, INPUT_PULLUP);  // initialize the button pin as a input:

  pinMode(ledPin, OUTPUT);  // initialize the LED as an output:

  Serial.begin(9600);  // initialize serial communication:
}

//this code will run repeatedly
void loop() {

  buttonState = digitalRead(buttonPin);  // read the pushbutton input:


  if (buttonState != lastButtonState) {  // compare the buttonState to its previous state

    if (buttonState == LOW) {  // if the state has changed, increment the counter
      buttonPushCounter++;     // if the current state is LOW then the button went from off to on:
      Serial.println("button is pressed");
      Serial.print("number of button pushes: ");
      Serial.println(buttonPushCounter);
    } else {

      Serial.println("button is not pressed");  // if the current state is LOW then the button went from on to off:
    }
    delay(10);
  }

  lastButtonState = buttonState;  // save the current state as the last state, for next time through the loop

  if (buttonPushCounter % 4 == 0) {  // turns on the LED every four button pushes by checking the modulo of the
    digitalWrite(ledPin, LOW);       // button push counter. the modulo function gives you the remainder of the
  } else {                           // division of two numbers:
    digitalWrite(ledPin, HIGH);
  }
}
