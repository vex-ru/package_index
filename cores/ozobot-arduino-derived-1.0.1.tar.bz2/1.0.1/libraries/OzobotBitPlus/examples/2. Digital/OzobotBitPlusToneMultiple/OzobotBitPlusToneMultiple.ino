/*
  Ozobot Bit+ 
  Multiple tone player

  Plays multiple tones between both Ozobot Bit+ in a sequence
  while making your Bit+ dance.



  created 8 Mar 2010
  by Tom Igoe
  based on a snippet from Greg Borenstein
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/toneMultiple
*/

// this code runs once when you power up the Bit+
void setup() {
}

//this code will run repeatedly
void loop() {

  noTone(MOTOR_RIGHT_PWM);  // turn off tone function for right motor:

  tone(MOTOR_LEFT_PWM, 440, 200);  // play a note on left motor for 200 ms:
  delay(300);          // wait for 300 milliseconds


  noTone(MOTOR_LEFT_PWM);         // turn off tone function for left motor:
  tone(MOTOR_RIGHT_PWM, 494, 500);  // play a note on right motor for 500 ms:
  delay(600);         // wait for 600 milliseconds


  noTone(MOTOR_RIGHT_PWM);  // turn off tone function for right motor:

  tone(MOTOR_LEFT_PWM, 523, 300);  // play a note on left motor for 300 ms:
  delay(400);          // wait for 400 milliseconds


  noTone(10);         // turn off tone function for left motor
  tone(9, 220, 200);  // play a note on right motor for 200ms:
  delay(300);         // wait for 300 milliseconds
}
