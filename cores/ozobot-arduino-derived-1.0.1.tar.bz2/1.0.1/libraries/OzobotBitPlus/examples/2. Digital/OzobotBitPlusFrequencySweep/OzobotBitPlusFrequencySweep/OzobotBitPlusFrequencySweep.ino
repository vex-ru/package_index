/*
  Ozobot Bit+
  Frequency Sweep

  Use the DC motor as a speaker

  Demonstrates the principle of harnessing the vibrations of the coils within 
  a DC motor for the purpose of recreating sound much like a loudspeaker does

  MIT License

  Copyright (c) 2023 Ozo Edu

  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.

  Created 30 Mar 2023
  By Ozobot

*/

unsigned int frequency = 1;   // sets tone() starting frequency in Hz
char sweepValue = 10;  //sets how many Hz to change the output by each time the loop runs, and how long to wait in milliseconds
char sweep = 1;      // creates a condition to control whether the frequency sweeps up or down
void setup() {

  pinMode(MOTOR_LEFT_PWM, OUTPUT);  //sets left motor pin as output
}

void loop() {

  if (sweep == 1) {  //checks to see if the frequency should sweep up

    noTone(MOTOR_LEFT_PWM);           //shuts off tone() output to allow for a clean update of frequency
    tone(MOTOR_LEFT_PWM, frequency);  //outputs next frequency to be played
    delay(sweepValue);                //waits before updating frequency integer

    frequency = (frequency + sweepValue);  //increases frequency integer by the sweepValue
    if (frequency >= 24000) {              //checks to see if the frequency is at the maximum
      sweep = 2;                           //sets sketch to sweep the frequency down if maximum has been reached
    }
  }
  if (sweep == 2) {  //checks to see if the frequency should sweep down

    noTone(MOTOR_LEFT_PWM);           //shuts off tone() output to allow for a clean update of frequency
    tone(MOTOR_LEFT_PWM, frequency);  //outputs next frequency to be played
    delay(sweepValue);                //waits before updating frequency integer

    frequency = (frequency - sweepValue);  //decreases frequency integer by the sweepValue
    if (frequency <= 1) {                  //checks to see if the frequency is at the minimum
      sweep = 1;                           //sets sketch to sweep the frequency up if minimum has been reached
    }
  }
}
