/*
  Ozobot Bit+
  Button

  Turns on and off a built-in LED 
  when pressing a pushbutton on the side of the Bit+

  created 2005
  by DojoDave <http://www.0j0.org>
  modified 30 Aug 2011
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/Button
*/

// variables will change:
int buttonState = 0;  // variable for reading the pushbutton status

// this code runs once when you power up the Bit+
void setup() {
  // this code will run once when the Bit+ is powered up
  // initialize the LED pin as an output:

  pinMode(LED_BLUE, OUTPUT);  // selected LED for output
                              // valid options are LED_RED, LED_GREEN, LED_BLUE, PIN_SENSORS_GREEN, PIN_SENSORS_WHITE

  pinMode(BUTTON_PIN, INPUT_PULLUP);  // initialize the pushbutton pin as an input:
}

//this code will run repeatedly
void loop() {

  buttonState = digitalRead(BUTTON_PIN);  // read the state of the pushbutton value:


  if (buttonState == LOW) {  // check if the pushbutton is pressed. If it is, the buttonState is LOW:

    digitalWrite(LED_BLUE, LOW);  // turn LED on:
  } else {

    digitalWrite(LED_BLUE, HIGH);  // turn LED off:
  }
}
