/*
  Ozobot Bit+
  Blink without Delay

  Turns on and off a built-in LED without using the delay() function. 
  This means that other code can run at the
  same time without being interrupted by the LED code.

  created 2005
  by David A. Mellis
  modified 8 Feb 2010
  by Paul Stoffregen
  modified 11 Nov 2013
  by Scott Fitzgerald
  modified 9 Jan 2017
  by Arturo Guadalupi
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/BlinkWithoutDelay
*/

// constants won't change
const int ledPin = LED_BLUE;  // the LED you wish to control with the the program
                              // valid options are: LED_RED, LED_GREEN, LED_BLUE, PIN_SENSORS_GREEN, and PIN_SENSORS_WHITE

// variables will change:
int ledState = HIGH;  // sets the default state of the LED to off 
                      // since the RGB package is active low we use HIGH for off and LOW for on

// when measuring time in milliseconds or microseconds, "unsigned long" is generally a good idea to store the data
unsigned long lastTimestamp = 0;  // will store last time LED was updated

// constants won't change
const long interval = 1000;  // how long it will take to update LED state, in milliseconds


// this code runs once when you power up the Bit+
void setup() {

  pinMode(ledPin, OUTPUT);  // selects LED for output valid options are:
                            //LED_RED, LED_GREEN, LED_BLUE, LED_SENSORS_GREEN, LED_SENSORS_WHITE
}

// this code runs over and over again
void loop() {


  if ((millis() - lastTimestamp) > interval) {  //reads 'millis()' to see if 1000 milliseconds has passed
                                                 //if it has been 1000 milliseconds the Bit+ will change the ledPin state
                                                 //subtracts lastTimestamp from current reading of millis(); to prevent overflow of variables

    lastTimestamp = millis();  // save the last time you blinked the LED

    if (ledState == HIGH) {  // if the LED is off turn it on and vice-versa:
      ledState = LOW;
    } else {
      ledState = HIGH;
    }

    digitalWrite(ledPin, ledState);  // set the LED with it's new state
  }
}