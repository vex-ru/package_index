/*
  Ozobot Bit+
  Melody

  Plays a familiar tune using the Bit+ motors

  created 21 Jan 2010
  modified 30 Aug 2011
  by Tom Igoe
  modified 5 Feb 2023
  by Ozobot

  This example code is in the public domain.

  https://www.arduino.cc/en/Tutorial/BuiltInExamples/toneMelody
*/

#include "pitches.h"


int tune[] = {  // notes in the tune:
  NOTE_C4, NOTE_G3, NOTE_G3, NOTE_A3, NOTE_G3, 0, NOTE_B3, NOTE_C4
};


int noteLengths[] = {  // note lengths: 4 = quarter note, 8 = eighth note, etc.:
  4, 8, 8, 4, 4, 4, 4, 4
};

// this code runs once when you power up the Bit+
void setup() {


  for (int currentNote = 0; currentNote < 8; currentNote++) {  // iterate over the notes of the melody

    int noteLength = 1000 / noteLengths[currentNote];  // to calculate the note length, take one second divided by the note value.
                                                       // e.g. quarter note = 1000 / 4, eighth note = 1000/8, etc.

    tone(MOTOR_RIGHT_PWM, tune[currentNote], noteLength);  // play tune on right motor
                                                       // change pin 9 to 10 to play on the left motor

    int restBetweenNotes = noteLength * 1.20;  // to break up the notes, set a minimum time between them.
                                               // the note's duration, feel free to experiment!
    delay(restBetweenNotes);

    noTone(MOTOR_RIGHT_PWM);  // stop the tone playing on the selected motor, valid options are: MOTOR_LEFT_PWM, MOTOR_RIGHT_PWM
  }
}

//this code will run repeatedly
void loop() {
  // we only need to hear the melody once, so no code is required in the loop
}
