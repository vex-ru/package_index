#ifndef Ozobot_h
#define Ozobot_h

void Ozobot_init(void);

// called after the user code in `setup()`
// TODO: this function will be deleted after we have hardware revision with external pull-up resistors
void Ozobot_postInit(void);

/**
 * sets the speed of left and right wheel
 * the arguments range is from -100 to 100
 * negative arguments mean reverse rotation (back)
 */
void Ozobot_setMotors(int left, int right);

#endif
