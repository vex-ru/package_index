#include "ozobot.h"

extern "C" void initVariant() {
    Ozobot_init();
}
