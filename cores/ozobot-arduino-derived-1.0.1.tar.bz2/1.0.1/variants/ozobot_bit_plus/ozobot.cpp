#include <avr/io.h>
#include "ozobot.h"

/**
 * (copied from ozobot-firmware/bit/src/drivers/motors.c)
 * configures TIMER1 for PWM generation
 */
void Ozobot_motorsInit(void) {
    DDRB |= 1<<PB1 | 1<<PB2; //set OCR1A and OCR1B as outputs
    DDRB |= 1<<PB6 | 1<<PB7; //set H-bridge direction outputs
    PORTB &= ~(1<<PB1 | 1<<PB2 | 1<<PB6 | 1<<PB7); // set them low (motors stopped)

    PRR0 &= ~(1<<PRTIM1); // enable timer1

    TCCR1B = 1<<WGM13   //Phase and Frequency Correct PWM,
                        // Mode: 8; TOP=ICR1, Update of OCR1x at BOTTOM, TOV1 Flag Set on BOTTOM
             | 1<<CS10; // prescaler 1 (no prescaling)

    TCCR1A = 1<<COM1A1 | 1<<COM1B1; // Clear OC1A/OC1B on Compare Match when upcounting.
                                    // Set OC1A/OC1B on Compare Match when downcounting.

    uint32_t const PWM_freqency_Hz = 40000; // the frequency is chosen such that the ICR1 calculates to 100
    ICR1 = F_CPU / PWM_freqency_Hz / 2;

    Ozobot_setMotors(0, 0);
}

void Ozobot_setMotors(int left, int right) {

    uint8_t portb = 0;

    if (left < 0) {
        left = -left;
        portb |= 1 << PB7;
    }

    if (right < 0) {
        right = -right;
        portb |= 1 << PB6;
    }

    if (left > ICR1) left = ICR1;
    if (right > ICR1) right = ICR1;

    uint8_t const mask = (1 << PB6) | (1 << PB7);
    OCR1A = right;
    OCR1B = left;
    PORTB = (PORTB & ~mask) | portb;
}

// Weak empty variant initialization function.
// May be redefined by user files
void Ozobot_init(void) __attribute__((weak));
void Ozobot_init(void) {
    // enable motor driver IC, LDO and color sensor IC
	DDRD |= 1 << PD7; // set the pin as output
    PORTD |= 1 << PD7; // set the pin high to enable peripheral ICs

    Ozobot_motorsInit();
}

// Weak empty variant initialization function.
// May be redefined by user files
void Ozobot_postInit(void) __attribute__((weak));
void Ozobot_postInit(void) {
    // configure button pull-up 
    PORTD |= 1 << PD2; 

    // configure charger pins as inputs
    DDRB &= ~(1 << PB0);
    DDRD &= ~((1 << PD3) | (1 << PD4));

    // pullups for charger IC pins
    PORTB |= 1 << PB0;
    PORTD |= (1 << PD3) | (1 << PD4);
}
